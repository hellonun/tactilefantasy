// ALL BUTTONS
let allkeys = ['1', '2', '3', '4', 'q', 'w', 'e', 'r', 'a', 's', 'd', 'f', 'z', 'x', 'c', 'v'];
// let keys1 = ['a', 's', 'd', 'f']; // words
// let keys2 = ['z', 'x', 'c', 'v']; // sounds
// let keys3 = ['q', 'w', 'e', 'r']; // animation
// let keys4 = ['1', '2', '3', '4']; // brightness
let keys1 = [];
let keys2 = [];
let keys3 = [];
let keys4 = [];

// WORDS
let saves = []; // store sentence
let d = 0; // iterate through words in sentence
let characters = 300; // total character in sentence
let names;
let order = 5; // accuracy
let ngrams = {};
let beginnings = [];
let button;
let ws = [];
let displayText;
let textBrightness = 100;

// SOUNDS
let sounds = [];
let polys = [
  [70, 60, 75],
  [60, 50, 55],
  [45, 40, 30],
  [35, 30, 25]
]; // poly combo
let ss = [0, 0, 0, 0, 0, 0]; // sound files to play
let state = 0; // what button is pressed
let randomPanicBeat;
let volume = 1;

// VISUALS
let ncols = 4;
let nrows = 4;
let w, h;
let a = 60; // angle
let aspeed = 0.01; // set up speed

// BRIGHTNESS LEVEL
let brightnessLevels = [4, 8, 12, 16];
let brightnessLevel = 10; // new b level
let pbrightnessLevel = 10; // previous b level
let finalLevel = 10; // previous b level

function preload() {
  // SHUFFLE ALL KEYS
  shuffle(allkeys, true); // keys

  keys1 = [allkeys[0], allkeys[1], allkeys[2], allkeys[3]];
  keys2 = [allkeys[4], allkeys[5], allkeys[6], allkeys[7]];
  keys3 = [allkeys[8], allkeys[9], allkeys[10], allkeys[11]];
  keys4 = [allkeys[12], allkeys[14], allkeys[14], allkeys[15]];



  // WORDS
  names = loadStrings('names.txt');

  // SOUNDS
  for (i = 0; i < 4; i++) {
    sounds.push(loadSound(str(i) + ".mp3"));
  }
}

function setup() {
  createCanvas(400, 400);
  // WORDS
  for (let j = 0; j < names.length; j++) {
    let txt = names[j];
    for (let i = 0; i <= txt.length - order; i++) {
      let gram = txt.substring(i, i + order);
      if (i == 0) {
        beginnings.push(gram);
      }

      if (!ngrams[gram]) {
        ngrams[gram] = [];
      }
      ngrams[gram].push(txt.charAt(i + order));
    }
  }
  markovIt();

  // VISUALS
  w = width / ncols;
  h = height / nrows;
  colorMode(HSB, 360, 100, 100);
  noStroke();

}

function keyTyped() {
  // WORDS
  for (i = 0; i < 4; i++) { // print this amount of words
    // WORDS
    if (key === keys1[i]) {
      ws = [];
      for (n = 0; n < i+1; n++) {
        if (saves[0][d + n]) {
          ws.push(saves[0][d + n]);
        }
      }
      displayText = (str(join(ws, ' '), width / 2, height / 2));
      d = d + i + 1;


      // SOUNDS 
    } else if (key === keys2[i]) {
      state = i;
      for (n = 0; n < ss.length; n++) {
        ss[n] = int(random(0, 4)); // random sound1
      }
      shuffle(polys, true); // shuffle polys beat
      randomPanicBeat = int(random(10, 25)); // random panic beat

      // VISUALS
    } else if (key === keys3[i]) {
      aspeed = map(i, 0, 3, 0.01, 0.2);
      // b = map(i, 0, 3, 20, 10);
    } else if (key === keys4[i]) {
      brightnessLevel = brightnessLevels[i];
    }


  }
  //WORDS
  if (d >= saves[0].length) {
    d = 0;
    markovIt();
  }
}

function draw() {
  // STOP ALL
  if (frameCount > 7000) {
    finalLevel = finalLevel - 0.1;

  }
  if (frameCount > 7180) {
    volume = volume - 0.005;
    if (volume < 0) {
      volume = 0;
    }
    masterVolume(volume);
    textBrightness--;
  }


  // SOUNDS
  if (state == 0) {
    if (frameCount % 90 == 0) {
      sounds[ss[0]].play(0, 1, 1, 0, 0.15); // play press
    } else if (frameCount % 90 == 45) {
      sounds[ss[0]].play(0, 1, 1, 0.5, 0.15); // play release
    }
  }
  // random 2 voices rhythm (same button)
  if (state == 1) {
    if (frameCount % polys[0][0] == 0) {
      sounds[ss[1]].play(0, 1, 1, 0, 0.15); // play press
    }
    if (frameCount % polys[0][1] == 0) {
      sounds[ss[1]].play(0, 1, 1, 0.5, 0.15); // play release
    }
  }
  // random voices rhythm (different buttons)
  if (state == 2) {
    if (frameCount % polys[0][0] == 0) {
      sounds[ss[2]].play(0, 1, 1, 0, 0.15); // play press
    }
    if (frameCount % polys[0][1] == 0) {
      sounds[ss[3]].play(0, 1, 1, 0.5, 0.15); // play release
    }
    if (frameCount % polys[0][2] == 0) {
      sounds[ss[4]].play(0, 1, 1, 0, 0.15); // play press
    }
  }
  // panic random rhythm
  if (state == 3) {
    if (frameCount % randomPanicBeat == 0) {
      sounds[ss[5]].play(0, 1, 1, 0, 0.15); // play press
    } else if (frameCount % randomPanicBeat == 5) {
      sounds[ss[5]].play(0, 1, 1, 0.5, 0.15); // play release
    }
  }

  // BRIGHTNESS LEVEL
  if (frameCount <= 6000) {
    if (brightnessLevel > pbrightnessLevel) {
      finalLevel += 0.1;
      pbrightnessLevel = finalLevel;
      // console.log("brightening");
    } else if (brightnessLevel < pbrightnessLevel) {
      finalLevel -= 0.1;
      pbrightnessLevel = finalLevel;
      // console.log("darkening");
    } else if (brightnessLevel == pbrightnessLevel) {
      finalLevel = brightnessLevel;
      pbrightnessLevel = finalLevel;
    }
  }

  // VISUALS
  a += aspeed;
  aspeed = bounce(a, 0, 360, aspeed);
  let hue = 0;
  for (let col = 0; col < ncols; col++) {
    for (let row = 0; row < nrows; row++) {
      hue += a;
      hue %= 180; // change color range

      fill(hue, 100, finalLevel);
      // fill(hue, 0, 0);
      let x = col * w;
      let y = row * h;
      noStroke();
      rect(x, y, w, h);
    }
  }

  //WORDS
  fill(0, 0, textBrightness);
  let textS = 20;
  textSize(textS);
  textAlign(CENTER, CENTER);
  text(displayText, width / 2, height / 2);
}

// WORDS
function markovIt() {
  let currentGram = random(beginnings);
  let result = currentGram;

  for (let i = 0; i < characters; i++) {
    let possibilities = ngrams[currentGram];
    if (!possibilities) {
      break;
    }
    let next = random(possibilities);
    result += next;
    let len = result.length;
    currentGram = result.substring(len - order, len);
  }
  saves.splice(0, 1, split(result, ' ')); // send the whole sentence 
}

// VISUALS
function bounce(a, low, high, speed) {
  if (a < low || a > high) {
    speed *= -1;
    return speed;
  }
  return speed;
}